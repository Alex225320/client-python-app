#/usr/bin/python3
"""
Usage:
 $ python3 load_generator.py
"""
import os
from random import randrange
import schedule
import subprocess
import time

NETWORK_TRAFFIC_COMMAND = "sudo nping -c 1 --data-length {} --tcp -p 80,433 cnn.com bbc.com"
FILE_READ_WRITE_COMMAND = "head -c {} </dev/urandom >{}"
TEMP_FILE = "./temp_rw.txt"

def load():
    subprocess.Popen(FILE_READ_WRITE_COMMAND.format(randrange(100000, 10000000), TEMP_FILE), shell=True)
    subprocess.Popen(NETWORK_TRAFFIC_COMMAND.format(randrange(10, 1400)), shell=True, stdout=subprocess.DEVNULL)
    
def main():
    # - generate some network traffic with nping ("-c 0" run continuously)
    # - generate some file read-write activity    
    if not os.path.exists(TEMP_FILE):
        os.mknod(TEMP_FILE)    
    
    schedule.every(5).seconds.do(load)
    while True:
        schedule.run_pending()
        time.sleep(1)
    
    
if __name__ == "__main__":
    main()
