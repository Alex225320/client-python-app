import argparse
from behave import *
import data_handler
import subprocess

def before_feature(context, feature):   
    try:
        output = subprocess.check_output(["which collectl"], stderr=subprocess.STDOUT,
                                         timeout=360, encoding="UTF-8", shell=True)
    except subprocess.CalledProcessError:
        raise 
    assert output

@given('{destination}')
def step_impl(context, destination):
    context.destination = destination.lower()

@when('we run script')
def step_impl(context):
    parser = argparse.ArgumentParser()
    args = parser.parse_args()
    args.test = True
    context.metricsDataHandler = data_handler.MetricsDataHandler(args)    
    context.collectedData = context.metricsDataHandler.collectData()
    assert(context.collectedData)
    if context.destination == "database":
        context.metricsDataHandler.saveDataToDB(context.collectedData)
    if context.destination == "s3":
        context.metricsDataHandler.saveDataToS3(context.collectedData)

@then('we can see collected data processed with an {action} as a result')
def step_impl(context, action):
    if action.lower().startswith("organized"):
        assert(context.scriptOutput is dict)
    if action.lower().startswith("saved"):
        if context.destination == "database":
            # TODO: verify data is present in database
            pass
        elif context.destination == "s3":
            # TODO: verify data is present in S3
            pass