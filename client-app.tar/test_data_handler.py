import argparse
import data_handler
import unittest
from unittest import TestCase
from unittest.mock import patch

class TestMetricsDataHandler(TestCase):
    def setUp(self):
        parser = argparse.ArgumentParser()
        args = parser.parse_args()
        args.test = True
        
        self.dh = data_handler.MetricsDataHandler(args)
    
    def testGetMeasurementID(self):
        self.assertEqual(self.dh.getMeasurementID("cpu"), 1)
        self.assertEqual(self.dh.getMeasurementID("cpu_sys"), 2)
        self.assertEqual(self.dh.getMeasurementID("mem_free"), 3)
        self.assertEqual(self.dh.getMeasurementID("mem_cach"), 4)
        self.assertEqual(self.dh.getMeasurementID("mem_inac"), 5)
        self.assertEqual(self.dh.getMeasurementID("disk_kbread"), 6)
        self.assertEqual(self.dh.getMeasurementID("disk_reads"), 7)
        self.assertEqual(self.dh.getMeasurementID("disk_kbwrit"), 8)
        self.assertEqual(self.dh.getMeasurementID("disk_writes"), 9)    
        self.assertEqual(self.dh.getMeasurementID("network_kb_in"), 10)     
        self.assertEqual(self.dh.getMeasurementID("network_pkt_in"), 11)    
        self.assertEqual(self.dh.getMeasurementID("network_kb_out"), 12)      
        self.assertEqual(self.dh.getMeasurementID("network_pkt_out"), 13)
        self.assertRaisesRegex(Exception, "No measurement named {0} found".format("NONEXISTING"), 
                                self.dh.getMeasurementID, "NONEXISTING")   

    @patch('subprocess.check_output')
    def testCollectData(self, check_output_mock):
        expected_output = """ waiting for 1 second sample...
        #<--------CPU--------><-----------Memory-----------><----------Disks-----------><----------Network---------->
        #cpu sys inter  ctxsw Free Buff Cach Inac Slab  Map KBRead  Reads KBWrit Writes   KBIn  PktIn  KBOut  PktOut 
           0   0   152    190 6626912 101808 619492 427100 335056 687180      0      0      0      0      0      0      0       0\n"""
        check_output_mock.return_value = expected_output
                
        result_data = self.dh.collectData()
        self.assertEqual(list(result_data.keys()), ["prefix", "data"])
        self.assertTrue(type(result_data["data"]) == list, "Data content expected to be a list")
        self.assertEqual(len(result_data["data"]), 2,#13, 
                         "Expected {} entries but found {} instead".format(13, len(result_data["data"])))

if __name__ == '__main__':
    unittest.main()
